import React from 'react'
import StoriesMain from './storiesPage'
import Explore from './exploreBtnPage'

export default function Stories() {
    return (
        <div>
            <StoriesMain/>
            <Explore/>
        </div>
    )
}
