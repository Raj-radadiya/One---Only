import React from 'react'
import PortonoviMain from './portonoviMain'

export default function Portonovi() {
  return (
    <div>
        <PortonoviMain/>
    </div>
  )
}
