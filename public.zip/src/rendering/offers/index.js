import React from 'react'
import OffersTitle from './offersTitle'

export default function Offers() {
  return (
    <div>
        <OffersTitle/>
    </div>
  )
}
