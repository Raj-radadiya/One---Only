import React from 'react'
import './herobanner.scss'
import Slider1 from '../../../layout/Slider'

export default function HeroBanner() {
    return (
        <div>
            <Slider1 />
        </div>
        
    )
}
